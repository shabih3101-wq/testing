"""
api.py  –  Minimal local REST API
==================================
Start with:
    python api.py

Then call:
    curl -X POST http://localhost:5000/answer \
         -H "Content-Type: application/json" \
         -d '{"question": "How long does a bank withdrawal take?"}'

Requires:  pip install flask
Optionally: ANTHROPIC_API_KEY env var for LLM-backed answers.
"""

import json
import math
import re
import string
import os
from collections import defaultdict
from pathlib import Path

try:
    from flask import Flask, request, jsonify
except ImportError:
    print("Flask not found.  Install it with:  pip install flask")
    raise

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

# ── Reuse pipeline helpers ───────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent
KB_DIR   = BASE_DIR / "kb"

STOPWORDS = {
    "a","an","the","is","it","in","on","of","to","and","or","for",
    "my","i","me","will","can","be","are","was","were","do","does",
    "have","has","had","not","but","with","from","at","this","that",
    "how","what","when","where","why","which","if","after","before",
    "by","about","up","than","so","he","she","they","we","you","its",
    "their","our","your","his","her","been","would","could","should",
    "may","might","also","just","more","any","all","no","as","long",
    "into","through","between","there","then","these","those",
}

def tokenize(text):
    text = text.lower().translate(str.maketrans("", "", string.punctuation))
    return [t for t in text.split() if t and t not in STOPWORDS]

def load_and_chunk():
    docs, chunks, counter = [], [], 0
    for path in sorted(KB_DIR.glob("*.txt")):
        raw = path.read_text(encoding="utf-8")
        lines = raw.splitlines()
        title = section = ""
        body_lines = []
        body_started = False
        for line in lines:
            if not body_started:
                if line.startswith("Title:"):    title   = line[6:].strip()
                elif line.startswith("Section:"): section = line[8:].strip()
                elif line.strip() == "" and title: body_started = True
            else:
                body_lines.append(line)
        body = "\n".join(body_lines).strip()
        docs.append({"doc_title": title, "section": section, "body": body})

    for doc in docs:
        body = doc["body"]
        offset = 0
        for sent in re.split(r'(?<=[.!?])\s+', body):
            sent = sent.strip()
            if not sent: continue
            start = body.find(sent, offset)
            end   = start + len(sent)
            chunks.append({
                "chunk_id": f"chunk_{counter}",
                "doc_title": doc["doc_title"],
                "section":   doc["section"],
                "text":      sent,
                "start_char": start,
                "end_char":   end,
            })
            counter += 1
            offset = end
    return chunks

def build_index(chunks):
    N = len(chunks)
    tf_store, doc_freq, tok_store = {}, defaultdict(int), {}
    for chunk in chunks:
        cid = chunk["chunk_id"]
        tokens = tokenize(chunk["text"])
        tok_store[cid] = tokens
        freq = defaultdict(int)
        for t in tokens: freq[t] += 1
        max_f = max(freq.values()) if freq else 1
        tf_store[cid] = {t: c / max_f for t, c in freq.items()}
        for t in freq: doc_freq[t] += 1
    idf = {t: math.log((N+1)/(df+1))+1 for t, df in doc_freq.items()}
    return {"tf": tf_store, "idf": idf}

def score(query, chunk_id, index):
    s = 0.0
    for t in tokenize(query):
        s += index["tf"].get(chunk_id, {}).get(t, 0.0) * index["idf"].get(t, 0.0)
    return round(s, 6)

def retrieve(question, chunks, index, top_k=3):
    scored = sorted(chunks, key=lambda c: score(question, c["chunk_id"], index), reverse=True)
    return scored[:top_k]

# ── Build index once on startup ──────────────────────────────────────────────
_chunks = load_and_chunk()
_index  = build_index(_chunks)
_client = anthropic.Anthropic() if ANTHROPIC_AVAILABLE and os.environ.get("ANTHROPIC_API_KEY") else None

# ── Flask app ────────────────────────────────────────────────────────────────
app = Flask(__name__)

@app.route("/answer", methods=["POST"])
def answer():
    data = request.get_json(force=True)
    question = data.get("question", "").strip()
    if not question:
        return jsonify({"error": "question field required"}), 400

    top = retrieve(question, _chunks, _index)
    context = "\n\n".join(
        f"[{c['doc_title']} §{c['chunk_id']}]\n{c['text']}" for c in top
    )

    if _client:
        prompt = f"""You are a citation-strict support assistant.

CONTEXT:
{context}

QUESTION: {question}

Answer using ONLY the context. Cite every fact as [Doc Title §chunk_id].
If context is insufficient say so.
Respond with JSON only:
{{"answer_label":"grounded_answer|insufficient_context","answer":"...","citations":["..."]}}"""
        response = _client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=512,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = response.content[0].text.strip()
        raw = re.sub(r"^```json\s*", "", raw); raw = re.sub(r"```$", "", raw)
        try:
            parsed = json.loads(raw)
        except Exception:
            parsed = {"answer_label": "insufficient_context", "answer": raw, "citations": []}
    else:
        # Local heuristic fallback
        best = top[0] if top else None
        if best:
            cit    = f"[{best['doc_title']} §{best['chunk_id']}]"
            parsed = {
                "answer_label": "grounded_answer",
                "answer":       f"{best['text']} {cit}",
                "citations":    [cit],
            }
        else:
            parsed = {
                "answer_label": "insufficient_context",
                "answer":       "I cannot answer this based on available information.",
                "citations":    [],
            }

    return jsonify(parsed)

if __name__ == "__main__":
    print("Starting Mini-RAG API on http://localhost:5000")
    print("POST /answer  {\"question\": \"...\"}")
    app.run(debug=True, port=5000)
