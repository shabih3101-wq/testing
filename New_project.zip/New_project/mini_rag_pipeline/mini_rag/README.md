# Mini RAG Pipeline

A replayable Retrieval-Augmented Generation pipeline that ingests a product
knowledge base, indexes it with TF-IDF, answers user questions with
citation-strict responses, and evaluates retrieval quality deterministically.

---

## Quick Start (Thonny / any Python 3.10+ terminal)

```bash
# 1. (Optional) install deps for LLM answers + API
pip install anthropic flask

# 2. Run the full pipeline
python pipeline.py

# 3. Validate all artifacts
python validate.py

# 4. (Optional) start the REST API
python api.py
```

---

## Project Layout

```
mini_rag/
├── kb/                         ← knowledge base plain-text articles
│   ├── article_01.txt
│   ├── article_02.txt
│   ├── article_03.txt
│   └── article_04.txt
├── queries.json                ← evaluation queries + ground truth
├── pipeline.py                 ← MAIN: all pipeline stages
├── validate.py                 ← standalone validation command
├── api.py                      ← optional Flask REST API
├── requirements.txt
├── artifacts/                  ← generated on each run (auto-created)
│   ├── chunks.json
│   ├── retrieval.json
│   ├── answers.json
│   ├── eval.json
│   ├── grounding_check.json
│   ├── chunking_comparison.json
│   └── manifest.json
└── llm_calls.jsonl             ← generated only when Anthropic key is set
```

---

## Pipeline Stages

```
INIT
 -> DOCUMENTS_LOADED      load all .txt files from kb/
 -> DOCUMENTS_CHUNKED     sentence-based + fixed-size chunking
 -> INDEX_BUILT           TF-IDF index over sentence chunks
 -> RETRIEVAL_COMPLETE    top-3 chunks per query with scores
 -> ANSWERS_GENERATED     citation-strict answers (LLM or heuristic)
 -> EVALUATION_COMPLETE   deterministic hit/miss per query
 -> VALIDATION_COMPLETE   all artifact checks pass
 -> RESULTS_FINALISED     manifest written
```

---

## LLM Usage

- If `ANTHROPIC_API_KEY` is set in your environment and the `anthropic` package
  is installed, answer generation uses **Claude Sonnet**.
- If not set, a **local keyword-heuristic fallback** is used automatically.
  The pipeline runs fully offline with no external dependencies.

Set the key (Windows):
```
set ANTHROPIC_API_KEY=sk-ant-...
```
Set the key (macOS/Linux):
```
export ANTHROPIC_API_KEY=sk-ant-...
```

---

## Controlled Vocabularies

| Field | Allowed values |
|---|---|
| `answer_label` | `grounded_answer` · `insufficient_context` · `conflicting_context` |
| `retrieval_status` | `hit` · `partial_hit` · `miss` |
| Citation format | `[Doc Title §chunk_id]` |

---

## REST API (optional)

```bash
python api.py
```

```bash
curl -X POST http://localhost:5000/answer \
     -H "Content-Type: application/json" \
     -d '{"question": "How long does a bank withdrawal take?"}'
```

Response:
```json
{
  "answer_label": "grounded_answer",
  "answer": "Bank withdrawals may take 1 to 3 business days after approval. [Cash withdrawal processing §chunk_5]",
  "citations": ["[Cash withdrawal processing §chunk_5]"]
}
```

---

## Replacing the Knowledge Base

1. Replace / add `.txt` files in `kb/`.
2. Each file must start with `Title: ...` and `Section: ...` lines,
   followed by a blank line, then the body text.
3. Re-run `python pipeline.py` – all artifacts regenerate automatically.

---

## No LLM Note

If `anthropic` is not installed or the API key is absent, the pipeline still
runs completely using a built-in TF-IDF retriever and a keyword-overlap answer
heuristic.  All artifacts are produced and all validation checks pass.
