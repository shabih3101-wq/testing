import json, math, re, string
from collections import defaultdict
from pathlib import Path

# ── tiny inline retriever ──────────────────────────────────────
STOPWORDS = {"a","an","the","is","it","in","on","of","to","and","or","for","my","i","me","will","can","be","are"}

def tokenize(text):
    text = text.lower().translate(str.maketrans("","",string.punctuation))
    return [t for t in text.split() if t not in STOPWORDS]

chunks = json.load(open("artifacts/chunks.json"))
N = len(chunks)
doc_freq = defaultdict(int)
tf_store = {}
for c in chunks:
    tokens = tokenize(c["text"])
    freq = defaultdict(int)
    for t in tokens: freq[t] += 1
    mf = max(freq.values()) if freq else 1
    tf_store[c["chunk_id"]] = {t: v/mf for t,v in freq.items()}
    for t in freq: doc_freq[t] += 1
idf = {t: math.log((N+1)/(df+1))+1 for t,df in doc_freq.items()}

def ask(question):
    scores = []
    for c in chunks:
        s = sum(tf_store[c["chunk_id"]].get(t,0)*idf.get(t,0) for t in tokenize(question))
        scores.append((c, round(s,4)))
    scores.sort(key=lambda x: x[1], reverse=True)
    print(f"\nQuestion: {question}")
    print("Top 3 results:")
    for i,(c,s) in enumerate(scores[:3],1):
        print(f"  {i}. [{c['doc_title']}]  score={s}")
        print(f"     {c['text']}")

# ── now test with your own questions ──────────────────────────
ask("How long does a bank withdrawal take?")
ask("Can support see my password?")
ask("Is a 7 month old utility bill accepted?")
ask("What happens if my account is under review?")
ask("Can I trade real money on a demo account?")