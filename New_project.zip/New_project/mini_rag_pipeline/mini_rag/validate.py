"""
validate.py
===========
Standalone validation command.  Run:

    python validate.py

Checks all required artifacts exist, JSON is valid, and all
controlled-vocabulary rules are satisfied.
"""

import json
import sys
from pathlib import Path

BASE_DIR = Path(__file__).parent

ANSWER_LABELS   = {"grounded_answer", "insufficient_context", "conflicting_context"}
RETRIEVAL_STATI = {"hit", "partial_hit", "miss"}

def main():
    errors = []

    # ── 1. Required artifacts ────────────────────────────────────────────────
    required = [
        "artifacts/chunks.json",
        "artifacts/retrieval.json",
        "artifacts/answers.json",
        "artifacts/eval.json",
        "artifacts/grounding_check.json",
        "artifacts/chunking_comparison.json",
    ]
    for rel in required:
        p = BASE_DIR / rel
        if not p.exists():
            errors.append(f"Missing artifact: {rel}")

    if errors:
        _report(errors)
        sys.exit(1)

    # ── 2. JSON valid ────────────────────────────────────────────────────────
    loaded = {}
    for rel in required:
        try:
            loaded[rel] = json.loads((BASE_DIR / rel).read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            errors.append(f"Invalid JSON in {rel}: {exc}")

    if errors:
        _report(errors)
        sys.exit(1)

    # ── 3. queries.json ───────────────────────────────────────────────────────
    queries_path = BASE_DIR / "queries.json"
    if not queries_path.exists():
        errors.append("Missing queries.json")
        _report(errors)
        sys.exit(1)
    queries      = json.loads(queries_path.read_text(encoding="utf-8"))
    query_ids    = {q["query_id"] for q in queries}

    retrieval    = loaded["artifacts/retrieval.json"]
    answers      = loaded["artifacts/answers.json"]
    eval_data    = loaded["artifacts/eval.json"]

    # ── 4. All queries processed ─────────────────────────────────────────────
    for qid in query_ids:
        if qid not in {r["query_id"] for r in retrieval}:
            errors.append(f"Query {qid} missing from retrieval.json")
        if qid not in {a["query_id"] for a in answers}:
            errors.append(f"Query {qid} missing from answers.json")

    # ── 5. At least 3 chunks per query ───────────────────────────────────────
    for r in retrieval:
        if len(r.get("top_k", [])) < 3:
            errors.append(f"{r['query_id']} has fewer than 3 retrieved chunks")

    # ── 6. Scores numeric ────────────────────────────────────────────────────
    for r in retrieval:
        for item in r.get("top_k", []):
            if not isinstance(item.get("score"), (int, float)):
                errors.append(f"Non-numeric score in {r['query_id']}")

    # ── 7. Answer label vocabulary ────────────────────────────────────────────
    for a in answers:
        if a.get("answer_label") not in ANSWER_LABELS:
            errors.append(f"Invalid answer_label in {a['query_id']}: {a.get('answer_label')}")

    # ── 8. Grounded answers have citations ────────────────────────────────────
    for a in answers:
        if a.get("answer_label") == "grounded_answer" and not a.get("citations"):
            errors.append(f"grounded_answer without citations in {a['query_id']}")

    # ── 9. Citations only from retrieved chunks ───────────────────────────────
    ret_map = {r["query_id"]: {i["chunk_id"] for i in r.get("top_k", [])} for r in retrieval}
    for a in answers:
        valid = ret_map.get(a["query_id"], set())
        for cid in a.get("used_chunk_ids", []):
            if cid not in valid:
                errors.append(f"{a['query_id']} cites unretrieved chunk '{cid}'")

    # ── 10. Evaluation statuses ───────────────────────────────────────────────
    for rec in eval_data.get("per_query", []):
        if rec.get("retrieval_status") not in RETRIEVAL_STATI:
            errors.append(
                f"Invalid retrieval_status in {rec['query_id']}: {rec.get('retrieval_status')}"
            )

    # ── 11. Aggregate summary ─────────────────────────────────────────────────
    summary = eval_data.get("summary", {})
    for key in ("top3_hit_rate", "total_queries", "hits", "partial_hits", "misses"):
        if key not in summary:
            errors.append(f"Aggregate summary missing key: {key}")

    _report(errors)
    sys.exit(0 if not errors else 1)


def _report(errors):
    if errors:
        print("\nVALIDATION FAILED:")
        for e in errors:
            print(f"  [FAIL] {e}")
    else:
        print("\nVALIDATION PASSED – all checks OK")


if __name__ == "__main__":
    main()
