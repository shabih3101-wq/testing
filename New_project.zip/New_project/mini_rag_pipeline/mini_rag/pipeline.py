"""
Mini RAG Pipeline
=================
Stages: INIT -> DOCUMENTS_LOADED -> DOCUMENTS_CHUNKED -> INDEX_BUILT
        -> RETRIEVAL_COMPLETE -> ANSWERS_GENERATED -> EVALUATION_COMPLETE
        -> VALIDATION_COMPLETE -> RESULTS_FINALISED
"""

import os
import json
import math
import re
import hashlib
import datetime
import string
from collections import defaultdict
from pathlib import Path

# ── Anthropic SDK (optional – used for grounded answer generation) ───────────
try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

# ── Controlled vocabularies ──────────────────────────────────────────────────
ANSWER_LABELS   = {"grounded_answer", "insufficient_context", "conflicting_context"}
RETRIEVAL_STATI = {"hit", "partial_hit", "miss"}
CITATION_RE     = re.compile(r"^\[.+ §chunk_\d+\]$")

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR       = Path(__file__).parent
KB_DIR         = BASE_DIR / "kb"
QUERIES_FILE   = BASE_DIR / "queries.json"
ARTIFACTS_DIR  = BASE_DIR / "artifacts"
LLM_CALLS_FILE = BASE_DIR / "llm_calls.jsonl"

ARTIFACTS_DIR.mkdir(exist_ok=True)

# ════════════════════════════════════════════════════════════════════════════
# STAGE TRACKER
# ════════════════════════════════════════════════════════════════════════════

STAGES = [
    "INIT", "DOCUMENTS_LOADED", "DOCUMENTS_CHUNKED", "INDEX_BUILT",
    "RETRIEVAL_COMPLETE", "ANSWERS_GENERATED", "EVALUATION_COMPLETE",
    "VALIDATION_COMPLETE", "RESULTS_FINALISED",
]

current_stage_idx = 0

def advance_stage(expected: str):
    global current_stage_idx
    assert STAGES[current_stage_idx] == expected, (
        f"Expected stage {expected}, currently at {STAGES[current_stage_idx]}"
    )
    print(f"  [STAGE] {expected}")
    current_stage_idx += 1

# ════════════════════════════════════════════════════════════════════════════
# STAGE 0 – INIT
# ════════════════════════════════════════════════════════════════════════════

advance_stage("INIT")

# ════════════════════════════════════════════════════════════════════════════
# STAGE 1 – LOAD DOCUMENTS
# ════════════════════════════════════════════════════════════════════════════

def load_documents(kb_dir: Path) -> list[dict]:
    """
    Read every .txt file in kb_dir.
    Each file must start with 'Title: ...' and 'Section: ...' lines,
    followed by a blank line, then the body text.
    """
    docs = []
    for path in sorted(kb_dir.glob("*.txt")):
        raw = path.read_text(encoding="utf-8")
        lines = raw.splitlines()

        title, section, body_lines = "", "", []
        body_started = False
        for line in lines:
            if not body_started:
                if line.startswith("Title:"):
                    title = line[len("Title:"):].strip()
                elif line.startswith("Section:"):
                    section = line[len("Section:"):].strip()
                elif line.strip() == "" and title:
                    body_started = True
            else:
                body_lines.append(line)

        body = "\n".join(body_lines).strip()
        docs.append({
            "filename": path.name,
            "doc_title": title,
            "section": section,
            "body": body,
        })
        print(f"    Loaded: {path.name}  title='{title}'")
    return docs


print("\n=== Loading documents ===")
documents = load_documents(KB_DIR)
assert documents, "No documents found in kb/"
advance_stage("DOCUMENTS_LOADED")

# ════════════════════════════════════════════════════════════════════════════
# STAGE 2 – CHUNKING  (two strategies)
# ════════════════════════════════════════════════════════════════════════════

def _make_chunk(chunk_id: str, doc: dict, text: str, start: int, end: int) -> dict:
    return {
        "chunk_id":   chunk_id,
        "doc_title":  doc["doc_title"],
        "section":    doc["section"],
        "text":       text,
        "start_char": start,
        "end_char":   end,
    }


def chunk_by_sentence(docs: list[dict]) -> list[dict]:
    """
    Strategy A – sentence-based (one sentence per chunk).
    Sentences are split on '.', '!' or '?' followed by whitespace or EOL.
    """
    chunks = []
    counter = 0
    for doc in docs:
        body = doc["body"]
        # Split keeping delimiters
        raw_sentences = re.split(r'(?<=[.!?])\s+', body)
        offset = 0
        for sent in raw_sentences:
            sent = sent.strip()
            if not sent:
                continue
            start = body.find(sent, offset)
            end   = start + len(sent)
            chunk_id = f"chunk_{counter}"
            chunks.append(_make_chunk(chunk_id, doc, sent, start, end))
            counter += 1
            offset = end
    return chunks


def chunk_by_fixed_size(docs: list[dict], size: int = 120, overlap: int = 20) -> list[dict]:
    """
    Strategy B – fixed-size character windows with overlap.
    """
    chunks = []
    counter = 0
    for doc in docs:
        body = doc["body"]
        start = 0
        while start < len(body):
            end  = min(start + size, len(body))
            text = body[start:end].strip()
            if text:
                chunk_id = f"chunk_{counter}"
                chunks.append(_make_chunk(chunk_id, doc, text, start, end))
                counter += 1
            if end == len(body):
                break
            start += size - overlap
    return chunks


print("\n=== Chunking documents ===")

# Primary strategy used by the rest of the pipeline: sentence-based
chunks_sentence = chunk_by_sentence(documents)
chunks_fixed    = chunk_by_fixed_size(documents)

# Save primary chunks
(ARTIFACTS_DIR / "chunks.json").write_text(
    json.dumps(chunks_sentence, indent=2, ensure_ascii=False), encoding="utf-8"
)
print(f"    Sentence-based chunks: {len(chunks_sentence)}")
print(f"    Fixed-size chunks:     {len(chunks_fixed)}")

advance_stage("DOCUMENTS_CHUNKED")

# ════════════════════════════════════════════════════════════════════════════
# STAGE 3 – BUILD TF-IDF INDEX
# ════════════════════════════════════════════════════════════════════════════

STOPWORDS = {
    "a","an","the","is","it","in","on","of","to","and","or","for",
    "my","i","me","will","can","be","are","was","were","do","does",
    "have","has","had","not","but","with","from","at","this","that",
    "how","what","when","where","why","which","if","after","before",
    "by","about","up","than","so","he","she","they","we","you","its",
    "their","our","your","his","her","been","would","could","should",
    "may","might","also","just","more","any","all","no","as","long",
    "into","through","between","there","then","these","those",
}

def tokenize(text: str) -> list[str]:
    text = text.lower()
    text = text.translate(str.maketrans("", "", string.punctuation))
    return [t for t in text.split() if t and t not in STOPWORDS]


def build_tfidf_index(chunks: list[dict]) -> dict:
    """
    Returns a dict with:
      - tf   : {chunk_id: {term: tf_score}}
      - idf  : {term: idf_score}
      - tokens: {chunk_id: [terms]}
    """
    N = len(chunks)
    tf_store   = {}
    doc_freq   = defaultdict(int)
    tok_store  = {}

    for chunk in chunks:
        cid    = chunk["chunk_id"]
        tokens = tokenize(chunk["text"])
        tok_store[cid] = tokens
        freq = defaultdict(int)
        for t in tokens:
            freq[t] += 1
        max_f = max(freq.values()) if freq else 1
        tf_store[cid] = {t: c / max_f for t, c in freq.items()}
        for t in freq:
            doc_freq[t] += 1

    idf = {t: math.log((N + 1) / (df + 1)) + 1 for t, df in doc_freq.items()}
    return {"tf": tf_store, "idf": idf, "tokens": tok_store}


def tfidf_score(query: str, chunk_id: str, index: dict) -> float:
    qtokens = tokenize(query)
    tf      = index["tf"].get(chunk_id, {})
    idf     = index["idf"]
    score   = 0.0
    for t in qtokens:
        score += tf.get(t, 0.0) * idf.get(t, 0.0)
    return round(score, 6)


print("\n=== Building TF-IDF index ===")
index_sentence = build_tfidf_index(chunks_sentence)
index_fixed    = build_tfidf_index(chunks_fixed)
print(f"    Vocabulary size (sentence index): {len(index_sentence['idf'])}")

advance_stage("INDEX_BUILT")

# ════════════════════════════════════════════════════════════════════════════
# STAGE 4 – RETRIEVAL
# ════════════════════════════════════════════════════════════════════════════

def retrieve(query: str, query_id: str, chunks: list[dict], index: dict, top_k: int = 3) -> dict:
    scores = [
        (chunk, tfidf_score(query, chunk["chunk_id"], index))
        for chunk in chunks
    ]
    scores.sort(key=lambda x: x[1], reverse=True)
    top = scores[:top_k]
    return {
        "query_id": query_id,
        "question": query,
        "top_k": [
            {
                "rank":       rank + 1,
                "chunk_id":   ch["chunk_id"],
                "doc_title":  ch["doc_title"],
                "score":      score,
                "chunk_text": ch["text"],
            }
            for rank, (ch, score) in enumerate(top)
        ],
    }


print("\n=== Running retrieval ===")
queries = json.loads(QUERIES_FILE.read_text(encoding="utf-8"))

retrieval_results_sentence = []
retrieval_results_fixed    = []

for q in queries:
    r_sent  = retrieve(q["question"], q["query_id"], chunks_sentence, index_sentence)
    r_fixed = retrieve(q["question"], q["query_id"], chunks_fixed,    index_fixed)
    retrieval_results_sentence.append(r_sent)
    retrieval_results_fixed.append(r_fixed)
    top_title = r_sent["top_k"][0]["doc_title"] if r_sent["top_k"] else "—"
    print(f"    {q['query_id']}: top doc = '{top_title}'")

(ARTIFACTS_DIR / "retrieval.json").write_text(
    json.dumps(retrieval_results_sentence, indent=2, ensure_ascii=False), encoding="utf-8"
)

advance_stage("RETRIEVAL_COMPLETE")

# ════════════════════════════════════════════════════════════════════════════
# STAGE 5 – ANSWER GENERATION  (LLM-backed, citation-strict)
# ════════════════════════════════════════════════════════════════════════════

def build_context_block(top_k: list[dict]) -> str:
    lines = []
    for item in top_k:
        lines.append(
            f"[{item['doc_title']} §{item['chunk_id']}]\n{item['chunk_text']}"
        )
    return "\n\n".join(lines)


def extract_citations(answer_text: str) -> list[str]:
    return re.findall(r"\[[^\]]+\]", answer_text)


def generate_answer_llm(q: dict, retrieval: dict, client) -> tuple[dict, dict | None]:
    """
    Call Claude to produce a citation-strict answer.
    Returns (answer_record, llm_call_log).
    """
    context = build_context_block(retrieval["top_k"])
    prompt  = f"""You are a citation-strict support assistant.

CONTEXT (retrieved chunks):
{context}

USER QUESTION: {q['question']}

INSTRUCTIONS:
1. Answer using ONLY the context above. Do not invent facts.
2. After every factual claim, add a citation in format [Doc Title §chunk_id].
3. If context is insufficient, reply exactly: "I cannot answer this based on available information."
4. Use exactly one of these labels in your JSON:
   - grounded_answer
   - insufficient_context
   - conflicting_context

Respond ONLY with valid JSON in this exact format (no markdown):
{{
  "answer_label": "<label>",
  "answer": "<your answer with inline citations>",
  "citations": ["<citation1>", "<citation2>"],
  "used_chunk_ids": ["<id1>"]
}}"""

    prompt_hash = hashlib.sha256(prompt.encode()).hexdigest()[:16]
    ts          = datetime.datetime.utcnow().isoformat() + "Z"

    response = client.messages.create(
        model      = "claude-sonnet-4-20250514",
        max_tokens = 1000,
        messages   = [{"role": "user", "content": prompt}],
    )
    raw_text = response.content[0].text.strip()

    # Strip ```json fences if present
    raw_text = re.sub(r"^```json\s*", "", raw_text)
    raw_text = re.sub(r"```$", "",      raw_text)

    try:
        parsed = json.loads(raw_text)
    except json.JSONDecodeError:
        parsed = {
            "answer_label":  "insufficient_context",
            "answer":        raw_text,
            "citations":     [],
            "used_chunk_ids": [],
        }

    # Enforce controlled vocabulary
    if parsed.get("answer_label") not in ANSWER_LABELS:
        parsed["answer_label"] = "insufficient_context"

    record = {
        "query_id":      q["query_id"],
        "answer_label":  parsed["answer_label"],
        "answer":        parsed["answer"],
        "citations":     parsed.get("citations", []),
        "used_chunk_ids": parsed.get("used_chunk_ids", []),
    }

    llm_log = {
        "stage":           "answer_generation",
        "query_id":        q["query_id"],
        "timestamp":       ts,
        "provider":        "anthropic",
        "model":           "claude-sonnet-4-20250514",
        "prompt_hash":     prompt_hash,
        "input_artifacts": ["artifacts/retrieval.json"],
        "output_artifact": "artifacts/answers.json",
    }
    return record, llm_log


def generate_answer_local(q: dict, retrieval: dict) -> dict:
    """
    Pure-Python fallback: keyword overlap heuristic.
    Finds the chunk whose words best overlap with the question,
    uses that chunk's text as the answer.
    """
    qtokens = set(tokenize(q["question"]))
    best_chunk = None
    best_score = -1

    for item in retrieval["top_k"]:
        ctokens = set(tokenize(item["chunk_text"]))
        overlap = len(qtokens & ctokens)
        if overlap > best_score:
            best_score  = overlap
            best_chunk  = item

    if best_chunk is None or best_score == 0:
        return {
            "query_id":      q["query_id"],
            "answer_label":  "insufficient_context",
            "answer":        "I cannot answer this based on available information.",
            "citations":     [],
            "used_chunk_ids": [],
        }

    citation = f"[{best_chunk['doc_title']} §{best_chunk['chunk_id']}]"
    return {
        "query_id":      q["query_id"],
        "answer_label":  "grounded_answer",
        "answer":        f"{best_chunk['chunk_text']} {citation}",
        "citations":     [citation],
        "used_chunk_ids": [best_chunk["chunk_id"]],
    }


print("\n=== Generating answers ===")

answers     = []
llm_logs    = []
use_llm     = ANTHROPIC_AVAILABLE and os.environ.get("ANTHROPIC_API_KEY", "")

if use_llm:
    print("    Using Anthropic LLM for answer generation")
    client = anthropic.Anthropic()
else:
    print("    No Anthropic API key found – using local heuristic fallback")

for i, q in enumerate(queries):
    ret = retrieval_results_sentence[i]
    if use_llm:
        record, llm_log = generate_answer_llm(q, ret, client)
        answers.append(record)
        llm_logs.append(llm_log)
    else:
        record = generate_answer_local(q, ret)
        answers.append(record)
    print(f"    {q['query_id']}: [{record['answer_label']}]  cites={record['citations']}")

(ARTIFACTS_DIR / "answers.json").write_text(
    json.dumps(answers, indent=2, ensure_ascii=False), encoding="utf-8"
)

if llm_logs:
    with open(LLM_CALLS_FILE, "w", encoding="utf-8") as fh:
        for log in llm_logs:
            fh.write(json.dumps(log) + "\n")

advance_stage("ANSWERS_GENERATED")

# ════════════════════════════════════════════════════════════════════════════
# STAGE 6 – DETERMINISTIC RETRIEVAL EVALUATION
# ════════════════════════════════════════════════════════════════════════════

def evaluate_retrieval(queries: list, retrieval_results: list) -> tuple[list, dict]:
    records = []
    hits = partial = misses = 0

    for q, ret in zip(queries, retrieval_results):
        expected  = set(q["expected_doc_titles"])
        top3_titles = [item["doc_title"] for item in ret["top_k"][:3]]
        matched_titles = expected & set(top3_titles)

        if matched_titles == expected:
            status      = "hit"
            explanation = f"Expected title(s) found in top 3: {sorted(matched_titles)}"
            hits += 1
        elif matched_titles:
            status      = "partial_hit"
            explanation = f"Partial match: found {sorted(matched_titles)}, missing {sorted(expected - matched_titles)}"
            partial += 1
        else:
            status      = "miss"
            explanation = f"Expected title(s) {sorted(expected)} not found in top 3"
            misses += 1

        records.append({
            "query_id":                  q["query_id"],
            "expected_doc_titles":       list(expected),
            "retrieved_doc_titles_top3": top3_titles,
            "retrieval_status":          status,
            "matched_expected_title":    bool(matched_titles),
            "explanation":               explanation,
        })

    total = len(queries)
    summary = {
        "top3_hit_rate": round(hits / total, 4) if total else 0.0,
        "total_queries": total,
        "hits":          hits,
        "partial_hits":  partial,
        "misses":        misses,
    }
    return records, summary


print("\n=== Evaluating retrieval ===")
eval_records_sentence, summary_sentence = evaluate_retrieval(queries, retrieval_results_sentence)
eval_records_fixed,    summary_fixed    = evaluate_retrieval(queries, retrieval_results_fixed)

eval_output = {
    "per_query": eval_records_sentence,
    "summary":   summary_sentence,
}
(ARTIFACTS_DIR / "eval.json").write_text(
    json.dumps(eval_output, indent=2, ensure_ascii=False), encoding="utf-8"
)

for r in eval_records_sentence:
    print(f"    {r['query_id']}: {r['retrieval_status']}  – {r['explanation']}")
print(f"\n    SUMMARY: hit_rate={summary_sentence['top3_hit_rate']}  "
      f"hits={summary_sentence['hits']}  "
      f"misses={summary_sentence['misses']}")

advance_stage("EVALUATION_COMPLETE")

# ════════════════════════════════════════════════════════════════════════════
# STAGE 7 – GROUNDING CHECK  (deterministic keyword / phrase overlap)
# ════════════════════════════════════════════════════════════════════════════

def grounding_check(answers: list, retrieval_results: list, chunks: list) -> list:
    chunk_map = {c["chunk_id"]: c for c in chunks}
    ret_map   = {r["query_id"]: r for r in retrieval_results}

    records = []
    for ans in answers:
        qid      = ans["query_id"]
        ret      = ret_map.get(qid, {})
        ret_ids  = {item["chunk_id"] for item in ret.get("top_k", [])}
        citation_checks = []

        for cit in ans.get("citations", []):
            # Extract chunk_id from "[Doc Title §chunk_X]"
            m   = re.search(r"§(chunk_\d+)", cit)
            cid = m.group(1) if m else None

            in_retrieval = cid in ret_ids if cid else False
            chunk        = chunk_map.get(cid, {}) if cid else {}
            chunk_text   = chunk.get("text", "").lower()

            # Heuristic: at least 2 answer tokens appear in chunk text
            ans_tokens   = set(tokenize(ans["answer"])) - STOPWORDS
            overlap      = [t for t in ans_tokens if t in chunk_text]
            supported    = in_retrieval and len(overlap) >= 2

            citation_checks.append({
                "citation":        cit,
                "chunk_id":        cid,
                "in_retrieval":    in_retrieval,
                "keyword_overlap": overlap[:10],
                "overlap_count":   len(overlap),
                "grounding_ok":    supported,
            })

        all_ok = all(c["grounding_ok"] for c in citation_checks) if citation_checks else (
            ans["answer_label"] == "insufficient_context"
        )
        records.append({
            "query_id":         qid,
            "answer_label":     ans["answer_label"],
            "citation_checks":  citation_checks,
            "all_citations_ok": all_ok,
        })

    return records


print("\n=== Running grounding checks ===")
grounding_records = grounding_check(answers, retrieval_results_sentence, chunks_sentence)
(ARTIFACTS_DIR / "grounding_check.json").write_text(
    json.dumps(grounding_records, indent=2, ensure_ascii=False), encoding="utf-8"
)
for r in grounding_records:
    print(f"    {r['query_id']}: all_citations_ok={r['all_citations_ok']}")

# ════════════════════════════════════════════════════════════════════════════
# CHUNKING COMPARISON
# ════════════════════════════════════════════════════════════════════════════

print("\n=== Chunking comparison ===")
comparison = {
    "strategies": [
        {
            "name":           "sentence_based",
            "description":    "One sentence per chunk, split on . ! ?",
            "num_chunks":     len(chunks_sentence),
            "avg_chunk_chars": round(
                sum(len(c["text"]) for c in chunks_sentence) / max(len(chunks_sentence), 1), 1
            ),
            "retrieval_summary": summary_sentence,
        },
        {
            "name":           "fixed_size",
            "description":    "Fixed 120-char window with 20-char overlap",
            "num_chunks":     len(chunks_fixed),
            "avg_chunk_chars": round(
                sum(len(c["text"]) for c in chunks_fixed) / max(len(chunks_fixed), 1), 1
            ),
            "retrieval_summary": summary_fixed,
        },
    ],
    "tradeoff_analysis": (
        "Sentence-based chunking preserves semantic units and avoids splitting "
        "a fact across two chunks, which helps TF-IDF match whole statements to queries. "
        "Fixed-size chunking risks splitting sentences mid-way, lowering term overlap. "
        "For short, factual KB articles, sentence-based chunking generally yields higher "
        "hit rates. Fixed-size chunks become more competitive when documents are longer "
        "and semantically dense, because sliding overlap ensures no sub-region is missed."
    ),
}
(ARTIFACTS_DIR / "chunking_comparison.json").write_text(
    json.dumps(comparison, indent=2, ensure_ascii=False), encoding="utf-8"
)
print(f"    Sentence hit_rate={summary_sentence['top3_hit_rate']}  "
      f"vs Fixed hit_rate={summary_fixed['top3_hit_rate']}")

# ════════════════════════════════════════════════════════════════════════════
# STAGE 8 – VALIDATION (inline; also callable via validate.py)
# ════════════════════════════════════════════════════════════════════════════

def run_validation() -> bool:
    errors = []

    # ── 1. Required artifacts exist ─────────────────────────────────────────
    required = [
        "artifacts/chunks.json",
        "artifacts/retrieval.json",
        "artifacts/answers.json",
        "artifacts/eval.json",
        "artifacts/grounding_check.json",
        "artifacts/chunking_comparison.json",
    ]
    for rel in required:
        p = BASE_DIR / rel
        if not p.exists():
            errors.append(f"Missing artifact: {rel}")

    if errors:
        for e in errors:
            print(f"  [FAIL] {e}")
        return False

    # ── 2. JSON validity ────────────────────────────────────────────────────
    for rel in required:
        try:
            json.loads((BASE_DIR / rel).read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            errors.append(f"Invalid JSON in {rel}: {exc}")

    # ── 3. Load artifacts ───────────────────────────────────────────────────
    def load(rel):
        return json.loads((BASE_DIR / rel).read_text(encoding="utf-8"))

    chunks_data    = load("artifacts/chunks.json")
    retrieval_data = load("artifacts/retrieval.json")
    answers_data   = load("artifacts/answers.json")
    eval_data      = load("artifacts/eval.json")

    query_ids      = {q["query_id"] for q in queries}

    # ── 4. All queries processed ────────────────────────────────────────────
    ret_ids = {r["query_id"] for r in retrieval_data}
    for qid in query_ids:
        if qid not in ret_ids:
            errors.append(f"Query {qid} missing from retrieval.json")

    ans_ids = {a["query_id"] for a in answers_data}
    for qid in query_ids:
        if qid not in ans_ids:
            errors.append(f"Query {qid} missing from answers.json")

    # ── 5. At least 3 retrieved chunks per query ────────────────────────────
    for r in retrieval_data:
        if len(r.get("top_k", [])) < 3:
            errors.append(f"Query {r['query_id']} has fewer than 3 retrieved chunks")

    # ── 6. Retrieval scores are numeric ─────────────────────────────────────
    for r in retrieval_data:
        for item in r.get("top_k", []):
            if not isinstance(item.get("score"), (int, float)):
                errors.append(f"Non-numeric score in {r['query_id']} rank {item.get('rank')}")

    # ── 7. Answer labels controlled vocabulary ──────────────────────────────
    for a in answers_data:
        if a.get("answer_label") not in ANSWER_LABELS:
            errors.append(f"Invalid answer_label '{a.get('answer_label')}' in {a['query_id']}")

    # ── 8. Grounded answers must have citations ──────────────────────────────
    for a in answers_data:
        if a.get("answer_label") == "grounded_answer" and not a.get("citations"):
            errors.append(f"grounded_answer with no citations in {a['query_id']}")

    # ── 9. Citations refer only to retrieved chunks ──────────────────────────
    ret_chunk_map = {}
    for r in retrieval_data:
        ret_chunk_map[r["query_id"]] = {item["chunk_id"] for item in r.get("top_k", [])}

    for a in answers_data:
        valid_ids = ret_chunk_map.get(a["query_id"], set())
        for cid in a.get("used_chunk_ids", []):
            if cid not in valid_ids:
                errors.append(
                    f"Answer {a['query_id']} cites chunk '{cid}' not in retrieval results"
                )

    # ── 10. Evaluation statuses controlled vocabulary ───────────────────────
    for rec in eval_data.get("per_query", []):
        if rec.get("retrieval_status") not in RETRIEVAL_STATI:
            errors.append(
                f"Invalid retrieval_status '{rec.get('retrieval_status')}' in {rec['query_id']}"
            )

    # ── 11. Aggregate summary present ───────────────────────────────────────
    summary = eval_data.get("summary", {})
    for key in ("top3_hit_rate", "total_queries", "hits", "partial_hits", "misses"):
        if key not in summary:
            errors.append(f"Aggregate summary missing key: {key}")

    # ── Report ───────────────────────────────────────────────────────────────
    if errors:
        print("\n  VALIDATION FAILED:")
        for e in errors:
            print(f"    [FAIL] {e}")
        return False
    else:
        print("\n  VALIDATION PASSED – all checks OK")
        return True


print("\n=== Running validation ===")
ok = run_validation()
assert ok, "Validation failed – see errors above."

advance_stage("VALIDATION_COMPLETE")

# ════════════════════════════════════════════════════════════════════════════
# STAGE 9 – FINALISE
# ════════════════════════════════════════════════════════════════════════════

# Write a manifest of all produced artifacts
manifest = {
    "produced_at": datetime.datetime.utcnow().isoformat() + "Z",
    "llm_used":    bool(use_llm),
    "artifacts": [
        str(p.relative_to(BASE_DIR))
        for p in sorted(ARTIFACTS_DIR.glob("*.json"))
    ],
}
(ARTIFACTS_DIR / "manifest.json").write_text(
    json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
)

advance_stage("RESULTS_FINALISED")

print("\n" + "="*60)
print("  Pipeline complete.")
print(f"  Hit rate (sentence): {summary_sentence['top3_hit_rate']}")
print(f"  Hit rate (fixed):    {summary_fixed['top3_hit_rate']}")
print("="*60)
